# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vngrok', 'vngrok.Functions']

package_data = \
{'': ['*']}

install_requires = \
['pexpect>=4.9.0,<5.0.0', 'pydantic>=2.8.2,<3.0.0']

setup_kwargs = {
    'name': 'vngrok',
    'version': '1.2.0',
    'description': 'This project aims to create one network revser load balancer you allow you to expose your local server to the internet using one external machine like a vps ',
    'long_description': '<h1 align="center">VNgrok</h1>\n<p align="center">\n    <a href="https://github.com/Vortex5Root/VNgrok/blob/master/LICENSE"><img src="https://img.shields.io/github/license/Vortex5Root/VNgrok.svg" alt="License">\n    <a href="https://github.com/Vortex5Root/VNgrok/releases"><img src="https://img.shields.io/github/downloads/Vortex5Root/VNgrok/total.svg" alt="GitHub all releases"></a><br>\n    <a href="https://github.com/Vortex5Root/VNgrok/network"><img src="https://img.shields.io/github/forks/Vortex5Root/VNgrok.svg" alt="GitHub forks"></a>\n    <a href="https://github.com/Vortex5Root/VNgrok/stargazers"><img src="https://img.shields.io/github/stars/Vortex5Root/VNgrok.svg" alt="GitHub stars"></a>\n    <a href="https://github.com/Vortex5Root/VNgrok/watchers"><img src="https://img.shields.io/github/watchers/Vortex5Root/VNgrok.svg" alt="GitHub watchers"></a><br>\n    <a href="https://github.com/Vortex5Root/VNgrok/issues"><img src="https://img.shields.io/github/issues/Vortex5Root/VNgrok.svg" alt="GitHub issues"></a>\n    <a href="https://github.com/Vortex5Root/VNgrok/pulls"><img src="https://img.shields.io/github/issues-pr/Vortex5Root/VNgrok.svg" alt="GitHub pull requests"></a>\n    <a href="https://github.com/Vortex5Root/VNgrok/commits/master"><img src="https://img.shields.io/github/last-commit/Vortex5Root/VNgrok.svg" alt="GitHub last commit"></a><br>\n    <a href="https://github.com/Vortex5Root/VNgrok/releases"><img alt="Dynamic TOML Badge" src="https://img.shields.io/badge/dynamic/toml?url=https%3A%2F%2Fraw.githubusercontent.com%2FVortex5Root%2FVNgrok%2Fmain%2Fpyproject.toml&query=%24.tool.poetry.version&logo=data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAAAolt3jAAAAtFBMVEVHcEyWYTihdkuXYzrBjlqhbkHepWuzglG8hFGWYjmzglHepmz3z5iygVCWYjmWYjmxgVDsvorMlmDepmybaD2oe02ufU2leUzdpWqzglGfdUrgqnH616j%2F4LKWYjmvf1C3hVPepmyWYjmWZDuWYjmzglGWYjmwfk7fp22aZjz93a7VoGmpfFKdbEe4hlTFkFzwxZH30aDpuYO%2BnICUbUbGkl3jrnbjr3eSYjuuiWzNq4fjvI5PAatoAAAAJXRSTlMA4v34FBH4Jwwn4l8IXFG6%2FrWcv2PCZqdJxeX291Ci4uVQ5eQoZPLoqAAAAIxJREFUCNdFzscCgjAQBNA1JIAGVMDeW0iEAPb6%2F%2F9lCuqc9s1eBkDHpxTDN8E8mroJ9S1G0Sw7noSbrAMAHLvidshMERPwVlUuxF0Vb7ltgtdi5VUV%2BetcNAwZKyv%2BeP7J%2BD6VRaq5rKmiOUGoW3OzAzxEF2npLIgaGPbN1%2Bm07S4SjvkPOnjQI%2Bb4AGCaEYNClUKKAAAAAElFTkSuQmCC&label=Package%20Version"></a>\n</p>\n\n<h2 align="center">Introduction</h2>\n\n> VNgrok is a program that creates a wrapper in the SSH tunnel function that allows you to host services without exposing your local ip address and also allows for you to switch ports without switching off your services. \n\n| Problem | Solution |\n| --- | --- |\n| **Trying to expose your services in a way that you don\'t have to expose your local IP and changing ports without switching off your services** | **We solved this problem by creating a wrapper in the SSH tunnel function to allow to host services** |\n\n<h2 align="center"> Index </h2>\n\n| Topic | Sub-Topic |\n| --- | --- |\n| [Dependencies](#dependencies) | |\n| [How To Install](#how-to-install) | |\n| [Documentation](#documentation) | |\n| [Acknowledgements](#acknowledgements) | |\n\n<h2 align="center">Dependencies</h2>\n\n| Name | Version | Description |\n| --- | --- | --- |\n| [![Linux](https://img.shields.io/badge/Linux-A81D33?style=for-the-badge&logo=linux&logoColor=ffffff)](https://www.linux.org/) | 5.14.0 | Linux is a family of open-source Unix-like operating systems based on the Linux kernel. |\n| [![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=ffdd54)](https://www.python.org/) | >=3.11 | Python is an interpreted high-level general-purpose programming language. |\n| [![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json?style=for-the-badge)](https://python-poetry.org/) | 1.1.8 | Poetry is a tool for dependency management and packaging in Python. |\n\n<h2 align="center">How To Install</h2>\n\n[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)\n```bash\npoetry init # To create a new project\n\npoetry add git+https://github.com/Vortex5Root/VNgrok.git\n```\n\n![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)\n```bash\npip install git+https://github.com/Vortex5Root/VNgrok.git#egg=vngrok\n```\n\n<h2 align="center">Documentation</h2>\n\nClick on the following image to go to the Documentation:\n\n<a href=./vngrok/DOCUMENTATION.md><img src="./img/wikipedia-svgrepo-com.svg" width=50></a> \n\n<h2 align="center">Acknowledgements</h2>\n\n<p align="center">\n    <br>[Coder]<br>\n    <a href="https://github.com/Vortex5Root"><img src=https://avatars.githubusercontent.com/u/102427260?s=200&v=4 width=50 style="border-radius: 50%;"><br>Vortex5Root <br><b>        {Full-Stack Software Engineer}</b></a><br>\n    <br>[Contributor]<br>\n    <a href="https://github.com/PandemicOfNukes"><img src=https://avatars.githubusercontent.com/u/59929476?s=200&v=4 width=50 style="border-radius: 50%;"><br>PandemicOfNukes <br><b>        {Student}</b></a><br><br>\n</p>\n',
    'author': 'Vortex5Root',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
